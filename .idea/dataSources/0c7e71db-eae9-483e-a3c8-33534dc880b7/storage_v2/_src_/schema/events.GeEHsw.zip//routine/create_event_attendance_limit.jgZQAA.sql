create
    definer = admin@`%` procedure create_event_attendance_limit(IN event_id_in int, IN attendance_limit_in int)
begin
    insert into event_limit(
        event_id
        ,attendance_limit)
    values (
        event_id_in
        ,attendance_limit_in
    );
end;

