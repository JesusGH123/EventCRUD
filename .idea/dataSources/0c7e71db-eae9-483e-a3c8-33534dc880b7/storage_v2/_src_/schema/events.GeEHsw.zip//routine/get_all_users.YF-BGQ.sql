create
    definer = admin@`%` procedure get_all_users()
begin
    select * from user;
end;

