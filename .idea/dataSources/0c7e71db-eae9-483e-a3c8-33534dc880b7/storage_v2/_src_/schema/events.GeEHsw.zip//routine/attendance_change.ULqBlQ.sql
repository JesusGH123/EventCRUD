create
    definer = admin@`%` procedure attendance_change(IN user_id_in int, IN event_id_in int, IN register tinyint(1))
begin
    if register
    then
        insert into
            attendance(
                    user_id
                    ,event_id
            )
            values(
                   user_id_in
                   ,event_id_in
            );
    else
        delete
            from attendance
            where
                  user_id = user_id_in
                  and event_id = event_id_in
        ;
    end if;
end;

