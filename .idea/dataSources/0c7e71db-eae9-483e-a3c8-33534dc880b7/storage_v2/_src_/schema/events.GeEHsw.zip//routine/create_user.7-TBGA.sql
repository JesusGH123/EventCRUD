create
    definer = admin@`%` procedure create_user(IN username_in varchar(50), IN is_admin_in tinyint(1),
                                              IN password_in varchar(224))
begin
    insert into user(username,is_admin, password) values(username_in,is_admin_in,sha2(password_in,224));
    select last_insert_id();
end;

