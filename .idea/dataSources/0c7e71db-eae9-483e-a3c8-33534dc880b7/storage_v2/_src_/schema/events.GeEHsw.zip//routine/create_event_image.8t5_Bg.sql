create
    definer = admin@`%` procedure create_event_image(IN event_id_in int, IN image_name_in varchar(100),
                                                     IN image_type_in varchar(100), IN image_size_in double,
                                                     IN image_content_in mediumblob)
begin
    insert into event_image(
        event_id
        ,name
        ,type
        ,size
        ,content
    ) values(
        event_id_in
        ,image_name_in
        ,image_type_in
        ,image_size_in
        ,image_content_in
    );
end;

