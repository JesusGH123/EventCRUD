create
    definer = admin@`%` procedure create_user(IN username_in varchar(50), IN password_in varchar(50))
begin
    insert into user(username, password) values(username_in,sha2(password_in,224));
    select last_insert_id();
end;

