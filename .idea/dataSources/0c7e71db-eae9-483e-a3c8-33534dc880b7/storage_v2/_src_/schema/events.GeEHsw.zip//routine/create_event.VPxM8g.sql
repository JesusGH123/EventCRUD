create
    definer = admin@`%` procedure create_event(IN title_in varchar(100), IN description_in text,
                                               IN category_in varchar(20), IN begin_date_in timestamp,
                                               IN end_date_in timestamp, IN price_in float)
begin
    insert into event(
        title
        ,description
        ,category
        ,begin_date
        ,end_date
        ,price
    )
    values(
        title_in
        ,description_in
        ,category_in
        ,begin_date_in
        ,end_date_in
        ,price_in
    );
    select last_insert_id();
end;

