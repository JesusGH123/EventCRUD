create
    definer = admin@`%` procedure delete_user(IN user_id_in int)
begin
    delete
        from user
        where user_id = user_id_in;
end;

