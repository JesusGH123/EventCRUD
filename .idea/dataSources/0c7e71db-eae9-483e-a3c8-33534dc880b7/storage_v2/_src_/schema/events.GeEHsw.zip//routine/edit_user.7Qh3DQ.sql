create
    definer = admin@`%` procedure edit_user(IN user_id_in int, IN username_in varchar(50), IN is_admin_in tinyint(1),
                                            IN password_in varchar(50))
begin
    update user
        set
            username = username_in
            ,is_admin = is_admin_in
            ,password = sha2(password_in,224)
        where
            user_id = user_id_in;
end;

